#!/bin/bash
APP="/Applications/TV Stats.app"
xattr -cr "$APP"
open "$APP"
