#!/bin/bash
APP="$(dirname "$0")/TV Stats.app"
xattr -cr "$APP"
open "$APP"
